import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../providers/product_provider.dart';
import '../providers/cart_provider.dart';
import '../screens/cart_screen.dart';
import '../screens/edit_product_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    Provider.of<ProductProvider>(context, listen: false).fetchProducts();
  }

  @override
  Widget build(BuildContext context) {
    final productProvider = Provider.of<ProductProvider>(context);
    final cartProvider = Provider.of<CartProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'GADGET INDIA',
          style: GoogleFonts.pacifico(
            fontSize: 24,
            fontWeight: FontWeight.w400,
            color: Colors.white,
          ),
        ),
        centerTitle: false,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFFE91E63),
                Color(0xFF9C27B0),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        actions: [
          Stack(
            children: [
              IconButton(
                icon: Icon(Icons.shopping_cart, color: Colors.white),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => CartScreen()),
                  );
                },
              ),
              if (cartProvider.items.isNotEmpty)
                Positioned(
                  right: 8,
                  top: 8,
                  child: CircleAvatar(
                    radius: 10,
                    backgroundColor: Colors.amber[700],
                    child: Text(
                      cartProvider.items.length.toString(),
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ),
                ),
            ],
          ),
          IconButton(
            icon: Icon(Icons.search, color: Colors.white),
            onPressed: () {},
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFCE4EC),
              Color(0xFFF8BBD0),
            ],
            stops: [0.1, 0.9],
          ),
        ),
        child: productProvider.isLoading
            ? Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    Color(0xFFE91E63),
                  ),
                ),
              )
            : productProvider.products.isEmpty
                ? Center(
                    child: Text(
                      'No products found',
                      style: GoogleFonts.poppins(
                        fontSize: 18,
                        color: Colors.pink[800],
                      ),
                    ),
                  )
                : Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 4, // Changed to 4 products per row
                        childAspectRatio: 0.6, // Adjusted aspect ratio for better fit
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                      ),
                      itemCount: productProvider.products.length,
                      itemBuilder: (ctx, i) {
                        final product = productProvider.products[i];
                        return Card(
                          elevation: 4, // Reduced elevation for compact view
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12), // Smaller radius
                          ),
                          shadowColor: Colors.pink.withOpacity(0.2),
                          color: Colors.white,
                          child: Padding(
                            padding: EdgeInsets.all(8), // Reduced padding
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 3, // Adjusted flex for image
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(8), // Smaller radius
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.pink.withOpacity(0.1),
                                          spreadRadius: 1,
                                          blurRadius: 4,
                                          offset: Offset(0, 2),
                                        ),
                                      ],
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(8),
                                      child: product.imageUrl != null
                                          ? Image.network(
                                              product.imageUrl!,
                                              width: double.infinity,
                                              fit: BoxFit.cover,
                                              errorBuilder: (context, error,
                                                      stackTrace) =>
                                                  Container(
                                                decoration: BoxDecoration(
                                                  gradient: LinearGradient(
                                                    colors: [
                                                      Color(0xFFF8BBD0),
                                                      Color(0xFFFCE4EC),
                                                    ],
                                                  ),
                                                ),
                                                child: Icon(
                                                  Icons.broken_image,
                                                  size: 24, // Smaller icon
                                                  color: Colors.pink[300],
                                                ),
                                              ),
                                            )
                                          : Container(
                                              decoration: BoxDecoration(
                                                gradient: LinearGradient(
                                                  colors: [
                                                    Color(0xFFF8BBD0),
                                                    Color(0xFFFCE4EC),
                                                  ],
                                                ),
                                              ),
                                              child: Center(
                                                child: Icon(
                                                  Icons.image,
                                                  size: 24, // Smaller icon
                                                  color: Colors.pink[300],
                                                ),
                                              ),
                                            ),
                                    ),
                                  ),
                                ),
                                SizedBox(height: 6), // Reduced spacing
                                Text(
                                  product.name,
                                  style: GoogleFonts.poppins(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 12, // Smaller font size
                                    color: Colors.pink[900],
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                Text(
                                  '₹${product.price.toStringAsFixed(2)}',
                                  style: GoogleFonts.poppins(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 14, // Smaller font size
                                    color: Color(0xFFE91E63),
                                  ),
                                ),
                                SizedBox(height: 4), // Reduced spacing
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    IconButton(
                                      padding: EdgeInsets.zero, // Remove padding
                                      iconSize: 18, // Smaller icon
                                      icon: Icon(
                                        Icons.edit,
                                        color: Colors.pink[400],
                                      ),
                                      onPressed: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) => EditProductScreen(
                                              product: product,
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                    IconButton(
                                      padding: EdgeInsets.zero, // Remove padding
                                      iconSize: 18, // Smaller icon
                                      icon: Icon(
                                        Icons.delete,
                                        color: Colors.pink[400],
                                      ),
                                      onPressed: () async {
                                        await Provider.of<ProductProvider>(
                                          context,
                                          listen: false,
                                        ).deleteProduct(product.id);
                                      },
                                    ),
                                    Container(
                                      width: 28, // Smaller container
                                      height: 28,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        gradient: LinearGradient(
                                          colors: [
                                            Color(0xFFE91E63),
                                            Color(0xFF9C27B0),
                                          ],
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.pink.withOpacity(0.3),
                                            blurRadius: 4,
                                            offset: Offset(0, 2),
                                          ),
                                        ],
                                      ),
                                      child: IconButton(
                                        padding: EdgeInsets.zero,
                                        iconSize: 14, // Smaller icon
                                        icon: Icon(
                                          Icons.add_shopping_cart,
                                          color: Colors.white,
                                        ),
                                        onPressed: () {
                                          cartProvider.addToCart(product);
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(
                                            SnackBar(
                                              content: Text(
                                                '${product.name} added to cart',
                                                style: GoogleFonts.poppins(
                                                  fontSize: 12, // Smaller font
                                                ),
                                              ),
                                              backgroundColor:
                                                  Color(0xFFE91E63),
                                              behavior:
                                                  SnackBarBehavior.floating,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(8),
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, '/add');
        },
        child: Icon(Icons.add, color: Colors.white),
        backgroundColor: Color(0xFFE91E63),
        elevation: 8,
        shape: CircleBorder(),
      ),
    );
  }
}