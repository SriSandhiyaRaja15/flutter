const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// GET all products
router.get('/', async (req, res) => {
  const products = await Product.find();
  res.json(products);
});

// GET single product
router.get('/:id', async (req, res) => {
  console.log('requested');
  const product = await Product.findById(req.params.id);
  console.log(product);
  res.json(product);
});

// POST a product
router.post('/', async (req, res) => {
  console.log(req.body);
  const {name,price,description,imageUrl} = req.body;
  const product = new Product({name,price,description,imageUrl});
  console.log(product);
  const product1 = await product.save(product);
  res.json(product1);
});

// PUT update product
router.put('/:id', async (req, res) => {
  const updated = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

// DELETE product
router.delete('/:id', async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ message: 'Product deleted' });
});

module.exports = router;
